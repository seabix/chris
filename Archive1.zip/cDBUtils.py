# cDBUtils.py
from mysql.connector import MySQLConnection, Error
import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode
from configparser import ConfigParser


""" ---------------------------------
Dec 4, 2023: All Database actions are here.
The idea is to paint the page in the appropriate
function and then send the query here to be 
processed.  The result list or tuple is returned.
Close the connection before every fetch.
_____________________________________ """
RECID = 0
STUDENTID = 1
INST = 2
PROGRAM = 3
MAJOR = 4
PWORD = 5
LASTNAME = 6
FIRSTNAME = 7
EMAIL = 8
PHONE = 9
LEVEL = 10
YEAR = 11
GROUP1 = 12
GROUP2 = 13
GROUP3 = 14
ROLE = 15
COURSESCOMPLETED = 16
# ==================================
def read_db_config(filename='config.ini', section='mysql'):
	""" Read database configuration file and return a dictionary object
	:param filename: name of the configuration file
	:param section: section of database configuration
	:return: a dictionary of database parameters
	"""
	# create parser and read ini configuration file
	parser = ConfigParser()
	parser.read(filename)

	# get section, default to mysql
	db = {}
	if parser.has_section(section):
		items = parser.items(section)
		for item in items:
			db[item[0]] = item[1]
	else:
		raise Exception('{0} not found in the {1} file'.format(section, filename))
	return db

# ==================================
def db_connect(task, query = "", dataToSave = ""):
	""" this version requires a -task- that identifies 
	the function/activity that is calling the db_connect.
	Since this function is used for inserting and searching
	there's default vars, query and dataToSave
	ACCEPTS: 	task
				query [default is blank]
				dataToSave [default is blank]
	RETURNS: the result set.
	"""
	x = read_db_config("config_cog2.ini")
	host = x["host"]
	db = x["database"]
	user = x["user"]
	password = x["password"]
	config = {
		'user': user, # 'root',
		'password': password, 
		'host': host,
		'database': db,
		'raise_on_warnings': True
	}
	#result = None
	row = None
	try:
		#print("<p>cDBUtils: Trying connection...")
		cnx = mysql.connector.connect(**config)
		#print("CNX = ", cnx)
		if cnx and cnx.is_connected():
			#print(" Connected. ")
			with cnx.cursor() as cursor:
				print(f"TASK =  {task}")
				if task == "add_new":
					cursor.execute(query)
					cnx.commit()
					#print("<h2>",cursor.rowcount,"</h2>")
					if cursor.rowcount > 1:
						print("<blockquote><p>Record saved.</p></blockquote>")
					else:
						print("<blockquote><p>Sorry, the record was not saved.</p></blockquote>")
				else:
					result = cursor.execute(query)
					row = cursor.fetchall()
				"""
				match task:
					case "login":
						#print("<b>cDBUtils</b> CASE IS LOGIN?")
						result = cursor.execute(query)
						row = cursor.fetchone()
					case "coursePref":
						#print("<br /><b>coursePref()</b><br />")
						result = cursor.execute(query)
						row = cursor.fetchall()
					case "saveBids":
						#print("<br /><b>Saving Bids from cBidding.setBids()</b><br />")
						result = cursor.execute(query)
						row = "Updated" # cursor.fetchone()
						#row = cursor.fetchall()
					case "addNewUser":
						pass
					case "byIDorName":
						#print("<br /><b>cDBUtils: byIDorName</b><br />")
						result = cursor.execute(query)
						row = cursor.fetchall()
					case "students_class_year":
						pass
					case "classes_class_year":
						result = cursor.execute(query)
						row = cursor.fetchall()
					case "edit_existing_user":
						result = cursor.execute(query)
						row = cursor.fetchall()
					case "updateStudentByFacAdmin":
						result = cursor.execute(query)
						row = cursor.fetchall()
				"""
		else:
			print("Sorry, could not connect to the database. ")
	except mysql.connector.Error as err:
		if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
			print(" Something is wrong with your user name or password")
		elif err.errno == errorcode.ER_BAD_DB_ERROR:
			print(" Database does not exist")
		else:
			print(" Sorry, an unknown database connection error has occurred: ", err)
	else:
		print(" Closing db connection.</p>")
		cursor.close()
		cnx.close()
	return row
# ==================================
