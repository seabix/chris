# cBidding.py
import cUtils
import cDBUtils

def runBiddingProgram(form):
	cUtils.pageMaker("resources/course_scout_bids_header.txt")
	print("<blockquote>Hi, Chris.  The bidding program runs but I want to tweak it a bit.</blockquote>")

def setBids(form):
	cUtils.pageMaker("resources/course_scout_bids_header.txt")
	print("Courses Bids for student id: ", form.getvalue('xid'))
	total_courses = form.getvalue("no_of_courses")
	print("<br />Total number of candidate courses: ",total_courses)
	print("<hr />")
	k = form.keys()
	tempdict = ""
	dataToSave = {} # dictionary for holding data to save
	print("<blockquote>Courses:<ol>")
	for i in range(0, len(k)):
		#print("<br />test in range - k[#] ", i, " ", k[i])
		if k[i][0:5] == "slide":
			idx = k[i].index(":") + 1
			# build data for the dictionary to save
			dataToSave[k[i][idx:]] = form.getvalue(k[i])
			#tempdict = tempdict + "'"+k[i][idx:]+"' = "+str(form.getvalue(k[i]))+","
			print("<li>", k[i][idx:], "  Bid = ", form.getvalue(k[i]), "</li>")
	print("</ol></blockquote>")
	tempdict = tempdict[:-1]

	# save the data here.
	print("<hr /><span id='dbSaveMsg'>Saving your choices ... calling db_connect()</span>")
		
	# TURNE OFF til dataToSave is correct.
	# from saveBids() - BUILD THE SQL STATEMENT
	#print("<p style='color:black;'>saveBids</p>")
	"""
	#print("trying to read the client course ids.")
	fileToRead = "client/demo_course_ids.txt"
	the_file = open(fileToRead, "r")
	course_ids = the_file.read()
	course_list = course_ids.split("\n")
	the_file.close()
	"""
	list_of_keys = list(dataToSave.keys())
	no_of_keys = len(list_of_keys)
	bid_insert = "SET @student_id = '"+form.getvalue("xid")+"'," + \
	"@term = 'Fall'," + \
	"@academic_year = '1999', "
	for i in range(0, no_of_keys):
		bid_insert += "@"+list_of_keys[i]+" = "+dataToSave.get(list_of_keys[i]) + ", "
	# remove final , and replace with ;
	bid_insert = bid_insert[:-2] + ";"

	# BUILD THE INSERT STATEMENT HERE ... 
	bid_insert = bid_insert + " INSERT INTO BIDS (student_id,term,academic_year,"
	for i in range(0, no_of_keys):
		bid_insert += list_of_keys[i]+", "
	bid_insert = bid_insert[:-2] + ") VALUES (@student_id, @term,@academic_year,"
	for i in range(0, no_of_keys):
		bid_insert += "@"+list_of_keys[i]+", "
	bid_insert = bid_insert[:-2] + ") ON DUPLICATE KEY UPDATE term = @term,academic_year = @academic_year,"

	for j in range(0, no_of_keys):
		bid_insert += list_of_keys[j] + " = @" + list_of_keys[j] + ","
	bid_insert = bid_insert[:-2]+";"


	# SPECIAL TEST IF INSERTED CORRECTLY:
	#bid_insert += "SELECT COUNT(*) AS updatedBids FROM bids;"
	#print("<br />561 STATEMENT = pageToShow == saveBids:<pre>", bid_insert, "</pre>")
	#print("Now calling bd_bids(bid_insert) ")
	
	# -----------------------
	# task = "bidInsert", dataToSave is the query
	#db_connect("saveBids", "s", dataToSave)
	# remember: task, query, datatosave ... 
	result = cDBUtils.db_connect("saveBids", "", dataToSave)
	
	# this is odd, I know, but for the moment ... 
	if result == "Updated":
		print("<p id='bidudpated'>Your bids have been saved.  You&rsquo;ll receive a candidate schedule shortly.</p>")
	else:
		print("<p>Sorry, the bid update was not possible.</p>")
	
	# CLOSE THE WEB PAGE
	cUtils.pageMaker("resources/course_scout_bids_footer.txt")
	#print("</body></html>")
	# admin/fac/tech staff can run the distribution script from their pages
