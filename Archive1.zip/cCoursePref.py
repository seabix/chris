#!/usr/local/bin/python3.10
import cgitb, cgi, sys, io, subprocess, traceback, os, stat, configparser
import datetime
from datetime import datetime
cgitb.enable() # display=0, logdir = "LOGS/")
from mysql.connector import MySQLConnection, Error
import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode
from configparser import ConfigParser
#import MySQLdb
#import pymysql
#import pymysql.cursors
#import storage
import cLogin
import cTech
import cUtils
import cDBUtils

# ccoursePref
RECNO = 0
SID = 1
PWORD = 2
LNAME = 3
FNAME = 4
EMAIL = 5
PHONE =  7
YEAR = 6
ROLE = 7
OTHER = 8
CLASS_SECTION_ID = 1
UNITS = 2
COURSE_NAME = 3
PROGRAM = 4
LEVEL = 5
PREREQ = 6
TERM = 7
COURSEYEAR = 8
DAY = 9
START_TIME = 10
END_TIME = 11
SLOTS = 12
ENROLLED = 13
EXTRA_SLOTS = 14
INSTRUCTOR_ID = 15
NOTES = 16

def print_column_names():
	startHour = 8
	endHour = 17
	for i in range(startHour, 12):
		print("<h2 class='time-slot' style='grid-row: time-"+str(i)+":00;'>"+str(i)+":00 am</h2>")
		print("<h2 class='time-slot' style='grid-row: time-"+str(i)+":30;'>"+str(i)+":30 am</h2>")
	for i in range(12, endHour):
		print("<h2 class='time-slot' style='grid-row: time-"+str(i)+":00;'>"+str(i)+":00 am</h2>")
		print("<h2 class='time-slot' style='grid-row: time-"+str(i)+":30;'>"+str(i)+":30 am</h2>")

def indiv_course(row, counter):
	# extract the start and end times, day of week
	# NOTE: day *must* look like Mon, Tue, Wed, Thu, Fri, Sat
	day = row[DAY]
	start = row[START_TIME] # must look like 0800 so change start_time to 0800
	end = row[END_TIME]
	
	s = '\n<div id="xc'+str(counter)+'score" ' + \
	'class="session session-1 track-'+day+'"' + \
	'style=\"grid-column: track-' + day + ';' + \
	'grid-row: time-'+start+' / time-'+end+';">' + \
	'\n\t<h3 class="session-title" >' + \
	'\n\t<a href="#">' + \
	'\n\t<span id="xc'+str(counter)+'scoretitle" onclick="showInfoBox('+str(counter)+')">' + \
	row[COURSE_NAME]+'</span></a></h3>' + \
	'\n\t<span class="session-time">'+start+' - '+end+'</span>' + \
	'\n\t<span class="session-track">'+row[CLASS_SECTION_ID]+' '+row[COURSE_NAME] + \
	'\n\tUnits: '+str(row[UNITS])+' Seats: '+str(row[SLOTS])+'/'+str(row[ENROLLED])+'</span>' + \
	'\n\t<span class="session-presenter">'+row[INSTRUCTOR_ID]+'</span>' + \
	'\n</div>'
	print(s)
	#return counter + 1


def getCoursesPref(user_option,xid,units,inclBreadth,inclMajor,major,student_name):
	""" send data back to end-user - create results """
	#print("The preferences ... in real practice this should link to the interactive bidder.")
	#print(f"wtf? ID: {z} units {units} inclMajor {inclMajor}, major {major}, user_option {useropt}")
	# print the headers first.... 
	#course_scout_header_1.txt
	#course_scout_body_1.txt
	# now the courses for the left side of the output. 	
	cUtils.pageMaker("resources/course_scout_header_1.txt")
	#print("<b>user_option,xid,units,inclBreadth,inclMajor,major,student_name</b>")
	# MUST HAVE THE STUDENT ID:
	print("<script>document.getElementById(\'user_name\').innerHTML = '"+student_name+"'</script>")
	s = ""
	i = 0
	
	q = "SELECT * FROM courses;"

	rows = cDBUtils.db_connect("coursePref", q)

	# for the required courseList
	no_of_classes = len(rows)+1
	#print("<h1># of courses: ", str(no_of_classes0-1) + "</h1>")
	print("\n<input type='hidden' name='student_name' id='student_name' value='"+student_name+"'>\n")
	print("<input type='hidden' name='xid' id='xid' value='"+xid+"'>\n")
	print("<input type='hidden' name='no_of_classes' id='no_of_classes' value='"+str(no_of_classes-1)+"'>\n")

	#var courseList = ['c1', 'c2', 'c3', 'c4','c5','c6', 'c7'];
	t = "<script>\nvar courseList = ["
	for j in range(1, no_of_classes):
		t = t + "'c"+str(j)+"'"
		if j < no_of_classes-1:
			t = t +", "
	t = t + "]\n</script>"
	print(t)
	CRECID = 0
	CCSI = 1
	CUNITS = 2
	CNAME = 3
	CPROGRAM = 4
	CLEVEL = 5
	CPREREQ = 6
	CTERM = 7
	CYEAR = 8
	CDAY = 9
	CSTART = 10
	CEND = 11
	CSLOTS = 12
	CENROLLED = 13
	CEXTRA = 14
	CINST = 15
	CNOTES = 16
	for row in rows:  # rows is a tuple; row is a list
		""" ORIGINAL
		s = "\n<div style='sliderCourse'>"
		s = s + "\n\t<b>" + str(row[RECNO]) + " " + row[CLASS_SECTION_ID] + " " + \
			"\n\tUnits: "+str(row[UNITS])+"</b>. " + row[COURSE_NAME]+".  " + \
			"\n\tMeets: "+row[DAY] + " " + row[START_TIME]+"-"+row[END_TIME]+ \
			"\n\t "+row[TERM]+" "+row[COURSEYEAR] + \
			"\n\tInst: " + row[INSTRUCTOR_ID] + ".<br />" + \
			"\n\tEnrollment: "+str(row[ENROLLED])+"/"+str(row[SLOTS]) + \
			"\n\t<input name='slider"+str(i)+":"+row[CLASS_SECTION_ID]+"' type='range' min='0' max='5' value='2' " + \
			"\n\tclass='slider' id='c"+str(i+1)+"'> " + \
			"\n\t<span class='scorer' id='c"+str(i+1)+"score'></span><br />" + \
			"\n<br /></div>"
		"""
		""" TEST: """
		s = "\n<div style='sliderCourse'>"
		s = s + "\n\t<b>" + str(row[CRECID]) + " " + row[CCSI] + " " + \
		"\n\tUnits: "+str(row[CUNITS])+"</b>. " + row[CNAME]+".  " + \
		"\n\tMeets: "+row[CDAY] + " " + row[CSTART]+"-"+row[CEND]+ \
		"\n\t "+row[CTERM]+" "+row[CYEAR] + \
		"\n\tInst: " + row[CINST] + ".<br />" + \
		"\n\tEnrollment: "+str(row[CENROLLED])+"/"+str(row[CSLOTS]) + \
		"\n\t<input name='slider"+str(i)+":"+row[CCSI]+"' type='range' min='0' max='5' value='2' " + \
		"\n\tclass='slider' id='c"+str(i+1)+"'> " + \
		"\n\t<span class='scorer' id='c"+str(i+1)+"score'></span><br />" + \
		"\n<br /></div>"
		print(s)
		i += 1
		
	# NOTE NOTE NOTE MOved the end form HERE
	print("\n<input type='hidden' name='user_option' id='user_option' value='b'>")
	print("\n</form>\n\n")
	# test
	#print("<h1>TEST: xid ", xid)
	# --------------------------
	cUtils.pageMaker("resources/course_scout_body_2.txt")

	print_column_names()

	# get each course and paint it by sending one row to the indiv_course area
	counter = 1
	for row in rows:
		#counter += indiv_course(row, counter)
		indiv_course(row, counter)
		counter += 1
		
	cUtils.pageMaker("resources/course_scout_body_3.txt")
		
	## IMPORTANT for display (innerHTML) and form (value)
	# UPDATE THE user_options AND xid, student_name, username,
		
	s = "\n<script>\n\tdocument.getElementById('sid').innerHTML = '"+xid + "';" + \
	"\n\tdocument.getElementById('xid').innerHTML = '"+xid+ "';" + \
	"\n\tdocument.getElementById('xid').value = '"+xid+ "';" + \
	"\n\tdocument.getElementById('student_name').innerHTML = '"+student_name + "';" + \
	"\n\tdocument.getElementById('sid').innerHTML = '"+xid + "';" + \
	';\n</script>'
	"""
	s = "\n<script>\n\tdocument.getElementById('sid').innerHTML = '"+row[SID] + "';" + \
	"\n\tdocument.getElementById('xid').innerHTML = '"+row[SID] + "';" + \
	"\n\tdocument.getElementById('xid').value = '"+row[SID] + "';" + \
	"\n\tdocument.getElementById('user_name').innerHTML = '"+student_name + "';" + \
	"\n\tdocument.getElementById('sid').innerHTML = '"+xid + "';" + \
	';\n</script>'
	"""
	#cUtils.pageMaker("resources/cognomos_default_footer.txt")