#!/usr/local/bin/python3.10
import cgitb, cgi, sys, io, subprocess, traceback, os, stat, configparser
import datetime
from datetime import datetime
cgitb.enable() # display=0, logdir = "LOGS/")
from mysql.connector import MySQLConnection, Error
import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode
from configparser import ConfigParser
#import MySQLdb
#import pymysql
#import pymysql.cursors
#import storage
import cLogin
import cTech
import cUtils
#import cDBUtils
import cCoursePref
import cBidding
import cReports

print("Content-Type: text/html; chartset=utf-8")
print("\n\n")

# get the option - login, preferences, update contacts
form = cgi.FieldStorage()
user_option = form.getvalue("user_option")

if __name__ == "__main__":
	if user_option == "l":  # login page passes "l" for user_option
		cLogin.getLoginData(form.getvalue('xid'),form.getvalue('pword'), form.getvalue('role'))
	elif user_option == "c":  # contact preferences option - not active.
		cTech.updateData()
	elif user_option == "p": # after logging in student, can set units, program, year
		cCoursePref.getCoursesPref(form.getvalue('user_option'),form.getvalue('xid'),form.getvalue('units'),form.getvalue('inclBreadth'),form.getvalue('inclMajor'),form.getvalue('major'),form.getvalue('student_name'))
	elif user_option == "b": #bids after selecting courses
		cBidding.setBids(form) #form.getvalue('xid'),form.getvalue('no_of_classes'))  
		# right now they're screwed up and in showConfirm()
	elif user_option == "runbid":
		cBidding.runBiddingProgram(form)
	elif user_option == "runroster":
		# runroster calls cReports to create the reports option menu page
		cReports.runCourseRoster()
	elif user_option == "reportMaker": # search for individual stu by id or lname
		cReports.reportMaker() # .getvalue('report_type'))
	elif user_option == "dbMaint": # tech staff only
		pass
		#cTech.dbMaint(form.getvalue('report_type'))
	else:
		showConfirm()

# ----------------------------- END OF THE SCRIPT cUseroptions.py 