# cUtils.py
""" ----------------- UTILITY module
Dec 4, 2023
Used throughout the scripts for writing 
error logs, screen pageWriting, email
--------------------------------- """

def pageMaker(fileToRead, reportType= ""):
	#fileToRead = "resources/cognomos_default_footer.txt"
	try:
		with open(fileToRead) as file:  # THE TEMPLATE
			data = file.read() #.replace('\n','')
		print(data)
	
		# here the reports option is just the full .txt page + the branding footer.
		print('<h2 id="activity"></h2>')
		s = '<script>\n\tdocument.getElementById("activity").innerHTML = "Reports Option: '+reportType+'";\n</script>'
		print(s)
	except FileNotFoundError as e:
		print(f"Sorry, the file ({fileToRead}) was not found: {e}")