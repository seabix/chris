# cTech.py
# Dec 4, 2023
""" --------------------------------
All work associated with the "t" or TechStaff
role are here.
Called by: cUseroptions -> user_option = "dbMaint"
------------------------------------ """


def updateData(form):
	print("Update Data: ", form)


def dbMaint():
	task = form.getvalue("task")
	if task == "createNewClient":
		pageMaker("resources/cognomos_default_header.txt", "Create New Client")
		inst = form.getvalue('inst')
		contact = form.getvalue('contact')
		email = form.getvalue('email')
		phone = form.getvalue('phone')
		
		s = "<p id='taskmsg'>This option will create a new database and tables for a new client.  Proceed with care.</p>"
		dataSubmitted = "<p>Client: "+inst+".  Contact "+contact+" at "+phone+" and "+email+"</p>"
		print(s, dataSubmitted)
		
	elif task == "updateClient":
		pageMaker("resources/cognomos_default_header.txt", "Update Client")
	elif task == "courseList":
		pageMaker("resources/cognomos_default_header.txt", "Review/Edit Course List")
	elif task == "transactionLogs":
		pageMaker("resources/cognomos_default_header.txt", "View Transaction Log")
