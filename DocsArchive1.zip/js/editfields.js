function updateData() {
	var x = document.getElementById("pword");
	if (x.style.display === "none") {
		x.style.display = "block";
		document.getElementById("saveChanges").style.display = "block";
		document.getElementById("pwordMsg").style.display = "block";
		document.getElementById("editIDButton").innerHTML = "Cancel";
	} else {
		x.style.display = "none";
		document.getElementById("editIDButton").innerHTML = "Edit";
		document.getElementById("saveChanges").style.display = "none";
		document.getElementById("pwordMsg").style.display = "none";
	}
}

/* editStudentList() is called by the Report option menu 
   in this demo version, not all the data are shown just lname,
   first, and SID.  The recid (record id) remains hidden unless
   end-user presses the Edit option.  Then its visibility status 
   is checked; if not displayed (display === "none") that means 
   we're not in an editable state; and vice versa.
*/

function editStudentList() {
	var x = document.getElementById("formrecid"); /* see line 630 or so */
	if (x.style.display === "none") {
		x.style.display = "block";
		document.getElementById("saveChanges").style.display = "inline-block;";
		document.getElementById("formsid").style.display = "inline-block;";
		document.getElementById("formcourse_section_id").style.display = "linline-blocklock";
		document.getElementById("formfirstname").style.display = "linline-blocklock";
		document.getElementById("formlastname").style.display = "inline-block;";
		document.getElementById("editIDButton").innerHTML = "<b>Cancel</b>";
	} else {
		x.style.display = "none";
		document.getElementById("editIDButton").innerHTML = "Edit";
		document.getElementById("saveChanges").style.display = "none";
	}
}