# cLogin.py
# Dec 4, 2023; Dec 7, 2023 3:30 p

import cLogin
import cTech
import cUtils
import cDBUtils

def getLoginData(xid, pword, role):
	cUtils.pageMaker("resources/ccognomos_default_header.txt")

	if role.upper() == "S":
		q = "SELECT * FROM students WHERE student_id='"+xid+"' AND pword='"+pword+"'"
	else:
		q = "SELECT * FROM users WHERE uid='"+xid+"' AND role = '"+role+"' AND pword='"+pword+"'";


	print(f"q is {q} about about to call db_connect()")
	
	rows = cDBUtils.db_connect("login", q) #coursePref

	#print("<b>Back from getLoginData()</b><br />")
	if len(rows) == 0: #  is None:
		print('<p id="dbresponse">Sorry, that username + password combination were not found.</p>')
	else: 
		if role.upper() == "S":
			RECID = 0
			STUDENT_ID = 1
			SINST = 2
			SPROGRAM = 3
			SMAJOR = 4
			SPWORD = 5
			SLAST_NAME = 6
			SFIRST_NAME = 7
			SEMAIL = 8
			SPHONE = 9
			SLEVEL = 10
			SYEAR = 11
			SGROUP1 = 12
			SGROUP2 = 13
			SGROUP3 = 14
			SROLE = 15
			SCOURSES_COMPLETED = 16
			SMODIFIEDBY = 17
			STERM = 18
			SACADYEAR = 19
			cUtils.pageMaker("resources/ccognomos_student_template.txt")
			#print("DB TEST: db_connect('login') ", row) # drawPage("pref", rows)
			#print("ROW TEST: lname test ", row[LNAME])
			for row in rows:
				t = str(row[SFIRST_NAME]) + " " + str(row[SLAST_NAME])
				s = "\n<script>\ndocument.getElementById('username').innerHTML = '"+t+"';" + \
							"\ndocument.getElementById('formlevel').value = '"+str(row[SLEVEL]) + "';" + \
							"\ndocument.getElementById('forminst').value = '"+str(row[SINST]) + "';" + \
							"\ndocument.getElementById('formprogram').value = '"+str(row[SPROGRAM]) + "';" + \
							"\ndocument.getElementById('formmajor').value = '"+str(row[SMAJOR]) + "';" + \
							"\ndocument.getElementById('formrole').value = '"+str(row[SROLE]) + "';" + \
							"\ndocument.getElementById('formsid').value = '"+str(row[STUDENT_ID]) + "';" + \
							"\ndocument.getElementById('xid').value = '"+str(row[STUDENT_ID]) + "';" + \
							"\ndocument.getElementById('formlname').value = '"+ row[SLAST_NAME] + "';" + \
							"\ndocument.getElementById('formfname').value = '"+ row[SFIRST_NAME] + "';" + \
							"\ndocument.getElementById('formemail').value = '"+str(row[SEMAIL]) + "';" + \
							"\ndocument.getElementById('formphone').value = '"+str(row[SPHONE]) + "';" + \
							"\ndocument.getElementById('formterm').value = '"+str(row[18]) + "';" + \
							"\ndocument.getElementById('formacadyear').value = '"+str(row[19])+"';\n</script>"
			print(s)
			print("<h2 id='loggedInAsStudent'>Student</h2>")
			print("<p class='status'>cLogin: s</p>")
			s = "\n<script>document.getElementById('student_name').value='"+t+"';</script>\n"
			print(s)
			cUtils.pageMaker("client/demo_client_footer.txt")
		elif role.upper() in "AF": #admin and faculty
			RECNO = 0
			UID = 1
			PWORD = 2
			ROLE = 3
			LNAME = 4
			FNAME = 5
			INST = 6
			EMAIL = 7
			PHONE = 8
			UPDATEDON = 9
			cUtils.pageMaker("resources/ccognomos_faculty_admin_template.txt")
			
			for row in rows:
				s = "\n<script>\ndocument.getElementById('userName').innerHTML = '"+row[FNAME]+" "+row[LNAME]+"';" + \
					"\ndocument.getElementById('role').innerHTML = '"+row[ROLE] + "';" + \
					"\ndocument.getElementById('uid').innerHTML = '"+row[UID] + "';\n</script>\n"
				print(s)
			print("<h2 id='loggedInAsAdminFac'>Administration and Faculty Users</h2>")
			print("<p class='status'>cLogin: admin/fact</p>")
			cUtils.pageMaker("client/demo_client_footer.txt")

		else: # finally tech
			print("<h2 id='loggedInAsTech'>Tech Group</h2>")
			t = row[4]+" "+row[5]
			s = "\n<script>\ndocument.getElementById('userName').innerHTML = '"+t+"';" + \
							"\ndocument.getElementById('role').innerHTML = '"+row[3] + "';" + \
							"\ndocument.getElementById('uid').innerHTML = '"+row[1] + "';\n</script>\n"
			print(s)
			cUtils.pageMaker("resources/ccognomos_tech_template.txt")
			print("<p class='status'>cLogin: tech</p>")
			s = ""
# ------------------------------------------------